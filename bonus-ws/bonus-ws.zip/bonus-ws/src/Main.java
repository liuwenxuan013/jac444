
public class Main {

    public static void main( String[] args ) {
        new ChessBoard(100);
    }
}
//TODO:
// 1.to change font shown on chessBoard
// 2.to add color change to show next intentional move
